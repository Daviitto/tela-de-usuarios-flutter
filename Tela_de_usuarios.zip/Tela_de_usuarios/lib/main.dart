import 'package:flutter/material.dart';
import 'package:tela_de_usuarios/listuser.dart';
import 'registeruser.dart';

void main() {
  runApp (MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) => RegisterUser(),
      '/listuser': (context) => Listuser(),
    },
  ));
}


