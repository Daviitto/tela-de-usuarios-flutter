import 'package:flutter/material.dart';

class EditUser extends StatefulWidget {
  final Map<String, String> usuario;

  const EditUser({super.key, required this.usuario});

  @override
  State<EditUser> createState() => _EditUserState();
}

class _EditUserState extends State<EditUser> {
  late TextEditingController _nomeController;

  @override
  void initState() {
    super.initState();
    // Inicializa o controller com o valor atual do usuário
    _nomeController = TextEditingController(text: widget.usuario['nome']);
  }

  @override
  void dispose() {
    _nomeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Editar Usuário')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextFormField(
              controller: _nomeController,
              decoration: const InputDecoration(
                labelText: 'Nome',
                hintText: 'Digite o nome',
                prefixIcon: Icon(Icons.person),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                // Cria o mapa atualizado e retorna para a tela anterior
                final usuarioAtualizado = {'nome': _nomeController.text};
                Navigator.pop(context, usuarioAtualizado);
              },
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );
  }
}
