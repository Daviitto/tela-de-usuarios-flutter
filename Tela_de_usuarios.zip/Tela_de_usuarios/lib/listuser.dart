import 'package:flutter/material.dart';
import 'package:tela_de_usuarios/edituser.dart';

class Listuser extends StatefulWidget {
  const Listuser({super.key});

  @override
  State<Listuser> createState() => _ListUserState();
}

class _ListUserState extends State<Listuser> {
  final List<Map<String, String>> _usuarios = [
    {'nome': 'Davi'},
    {'nome': 'Matheus'},
    {'nome': 'Gabriel'},
    {'nome': 'Enoque'}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lista de Usuários')),
      body: ListView.separated(
        itemCount: _usuarios.length,
        separatorBuilder: (context, index) => const Divider(),
        itemBuilder: (context, index) {
          final usuario = _usuarios[index];
          return ListTile(
            leading: const Icon(Icons.person),
            title: Text(usuario['nome']!),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.blue),
                  onPressed: () async {
                    // Abre a tela de edição e espera o resultado
                    final resultado = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => EditUser(usuario: _usuarios[index]),
                      ),
                    );

                    // Se a tela de edição retornou dados atualizados, atualiza a lista
                    if (resultado != null) {
                      setState(() {
                        _usuarios[index] = resultado;
                      });
                    }
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      _usuarios.removeAt(index);
                    });
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
