
import 'package:flutter/material.dart';

class RegisterUser extends StatefulWidget {
  const RegisterUser({super.key});


  @override
  State<RegisterUser> createState() => _RegisterUserState();
}

class _RegisterUserState extends State<RegisterUser> {
  // Controllers
    final _nomeController = TextEditingController();
    final _senhaController = TextEditingController();

    // Focus nodes
    final _nomeFocus = FocusNode();
    final _senhaFocus = FocusNode();


@override
  void dispose() {
    _nomeController.dispose();
    _senhaController.dispose();
    _senhaFocus.dispose();
    super.dispose();
}

@override
  Widget build (BuildContext context) {
  return Scaffold(
    appBar: AppBar(title: const Text('Form User')),
    body: Center(
      child: Column(
        children: [

         TextFormField(
           controller: _nomeController,
           decoration:  const InputDecoration(
             labelText: 'Nome',
           hintText: 'Digite seu Nome',
             prefixIcon: Icon(Icons.person),
           ),
           textInputAction: TextInputAction.next,
           onFieldSubmitted: (_) {
             FocusScope.of(context).requestFocus(_nomeFocus);
           },
         ),

          TextFormField(
            controller: _senhaController,
            decoration: const InputDecoration(
              labelText: 'Senha',
              hintText: 'Digite sua senha',
              prefixIcon: Icon(Icons.lock),
            ),
            textInputAction: TextInputAction.next,
            onFieldSubmitted: (_) {
              FocusScope.of(context).requestFocus(_senhaFocus);

            },
          ),

        SizedBox(height: 16),

          ElevatedButton(onPressed: ()
          {
            Navigator.pushNamed(context, '/listuser');
            print('Botão clicado');
            },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),

                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text ('Cadastrar')),
        ],
      ),
    ),
  );
}


}